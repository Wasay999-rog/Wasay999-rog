"use client"

import Link from "next/link"
import Image from "next/image"
import { FaArrowLeft, FaGithub, FaLinkedinIn } from "react-icons/fa"

export default function AboutMe() {
  return (
    <div className="bg-gradient-to-br from-black via-gray-900 to-black text-white min-h-screen p-5 md:p-10">
      <header className="max-w-4xl mx-auto flex justify-end mb-4">
        <div className="flex items-center gap-4">
          <a
            href="https://github.com/wasaymohammed"
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-300 hover:text-white transition-colors"
            aria-label="GitHub Profile"
          >
            <FaGithub className="text-2xl" />
          </a>
          <a
            href="https://linkedin.com/in/wasay-mohammed"
            target="_blank"
            rel="noopener noreferrer"
            className="text-gray-300 hover:text-white transition-colors"
            aria-label="LinkedIn Profile"
          >
            <FaLinkedinIn className="text-2xl" />
          </a>
        </div>
      </header>

      <div className="max-w-4xl mx-auto">
        <Link href="/" className="inline-flex items-center gap-2 mb-6 text-green-500 hover:text-green-400">
          <FaArrowLeft /> Back to Home
        </Link>

        <h1 className="text-3xl md:text-4xl font-bold mb-8">About Me</h1>

        <div className="flex flex-col md:flex-row gap-8 mb-12">
          <div className="w-full md:w-1/3">
            <div className="rounded-2xl overflow-hidden shadow-lg">
              <Image
                src="/images/wasay-snowmobile.png"
                alt="Wasay Mohammed on a snowmobile in the mountains"
                width={600}
                height={800}
                className="w-full object-cover"
              />
            </div>
          </div>
          <div className="w-full md:w-2/3">
            <div className="prose prose-lg prose-invert">
              <p className="text-gray-300 text-lg leading-relaxed">
                Hi, I'm Wasay Mohammed — your go-to guy when it comes to data. I've always been fascinated by numbers
                and patterns, even back in high school when I first realized how powerful data could be if we knew how
                to make sense of it.
              </p>

              <p className="text-gray-300 text-lg leading-relaxed mt-4">
                I'm passionate about statistics, probability, and algorithm design. Whether it's building data
                pipelines, creating dashboards, or transforming messy data into meaningful insights, I find joy in
                solving real-world problems through data.
              </p>

              <p className="text-gray-300 text-lg leading-relaxed mt-4">
                Outside of work, I love traveling and staying on top of what's happening in the tech world — especially
                around AI, analytics, and emerging data tools.
              </p>

              <p className="text-gray-300 text-lg leading-relaxed mt-4">
                I'm available for freelance and consulting opportunities. If you need help turning data into decisions,
                don't hesitate to reach out — I'd love to collaborate.
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12 border-t border-gray-700 pt-8">
          <h2 className="text-2xl font-semibold mb-4">Get in Touch</h2>
          <p className="text-gray-300 mb-4">
            If you're interested in working together or just want to connect, feel free to reach out through any of the
            following channels:
          </p>
          <ul className="text-gray-400 space-y-2">
            <li>Email: mohammedwasay69@outlook.com</li>
            <li>LinkedIn: linkedin.com/in/wasay-mohammed</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
