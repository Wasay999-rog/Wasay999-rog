"use client"

import { useParams } from "next/navigation"
import Link from "next/link"
import Image from "next/image"
import { FaArrowLeft, FaGithub, FaLinkedinIn } from "react-icons/fa"
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter"
import { dracula } from "react-syntax-highlighter/dist/esm/styles/prism"

// Project data (in a real app, this would likely come from a database or API)
const projectsData = [
  {
    slug: "hr-database",
    title: "HR Database",
    description: "Organize, track, and analyze employee data with SQL and Power BI.",
    image: "https://images.unsplash.com/photo-1554774853-aae0a22c8aa4?auto=format&fit=crop&w=800&q=60",
    fullDescription:
      "This project involved designing and implementing a comprehensive HR database system using SQL and Power BI. The system allows HR departments to efficiently manage employee data, track performance metrics, and generate insightful reports for decision-making.",
    technologies: ["SQL", "Power BI", "Database Design", "Data Modeling"],
    keyFeatures: [
      "Employee profile management",
      "Performance tracking dashboard",
      "Automated reporting system",
      "Data visualization for HR metrics",
    ],
    codeExample: {
      language: "sql",
      code: `-- Query to get employee performance metrics
SELECT 
    e.employee_id,
    e.first_name,
    e.last_name,
    d.department_name,
    AVG(p.performance_score) as avg_performance,
    COUNT(p.review_id) as review_count,
    MAX(p.review_date) as last_review_date
FROM 
    employees e
JOIN 
    departments d ON e.department_id = d.department_id
LEFT JOIN 
    performance_reviews p ON e.employee_id = p.employee_id
WHERE 
    e.status = 'Active'
    AND p.review_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 1 YEAR)
GROUP BY 
    e.employee_id, e.first_name, e.last_name, d.department_name
ORDER BY 
    avg_performance DESC;`,
    },
  },
  {
    slug: "movie-recommendation",
    title: "Movie Recommendation System",
    description: "Build a recommender using collaborative filtering and Scikit-learn.",
    image: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?auto=format&fit=crop&w=800&q=60",
    fullDescription:
      "Developed a sophisticated movie recommendation system using collaborative filtering techniques and Scikit-learn. The system analyzes user preferences and viewing history to suggest personalized movie recommendations.",
    technologies: ["Python", "Scikit-learn", "Collaborative Filtering", "Data Analysis"],
    keyFeatures: [
      "User-based collaborative filtering",
      "Content-based recommendation engine",
      "Rating prediction system",
      "Personalized user profiles",
    ],
    codeExample: {
      language: "python",
      code: `import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer

# Load movie data
movies_df = pd.read_csv('movies.csv')
ratings_df = pd.read_csv('ratings.csv')

# Create a user-item matrix
user_movie_ratings = ratings_df.pivot(
    index='userId', 
    columns='movieId', 
    values='rating'
).fillna(0)

# Calculate cosine similarity between users
user_similarity = cosine_similarity(user_movie_ratings)
user_similarity_df = pd.DataFrame(
    user_similarity,
    index=user_movie_ratings.index,
    columns=user_movie_ratings.index
)

# Function to get movie recommendations for a user
def get_user_recommendations(user_id, top_n=10):
    # Get similar users
    similar_users = user_similarity_df[user_id].sort_values(ascending=False)[1:11]
    
    # Get movies the user hasn't seen
    user_movies = set(ratings_df[ratings_df['userId'] == user_id]['movieId'])
    recommendations = []
    
    # Get top rated movies from similar users
    for similar_user, similarity in similar_users.items():
        if similarity <= 0:
            continue
            
        # Get highly rated movies from this similar user
        similar_user_movies = ratings_df[
            (ratings_df['userId'] == similar_user) & 
            (ratings_df['rating'] > 4)
        ]['movieId']
        
        # Add movies the target user hasn't seen
        for movie in similar_user_movies:
            if movie not in user_movies:
                movie_title = movies_df[movies_df['movieId'] == movie]['title'].values[0]
                recommendations.append((movie, movie_title, similarity))
    
    # Sort and return top N recommendations
    recommendations.sort(key=lambda x: x[2], reverse=True)
    return recommendations[:top_n]

# Example usage
user_recommendations = get_user_recommendations(42)
print("Recommended movies for user 42:")
for movie_id, title, score in user_recommendations:
    print(f"- {title} (Score: {score:.2f})")`
    },
  },
  {
    slug: "real-estate-scraper",
    title: "Real Estate Web Scraper",
    description: "Scrape property data with Python and automate listing analysis.",
    image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=800&q=60",
    fullDescription:
      "Created an automated web scraping tool that collects real estate listing data from multiple sources. The system processes and analyzes property information to identify market trends and investment opportunities.",
    technologies: ["Python", "BeautifulSoup", "Pandas", "Data Visualization"],
    keyFeatures: [
      "Automated data collection from multiple websites",
      "Property price analysis",
      "Market trend visualization",
      "Investment opportunity scoring",
    ],
    codeExample: {
      language: "python",
      code: `import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import random
from datetime import datetime

# List of user agents to rotate
user_agents = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko)'
]

def get_property_data(zip_code, page=1):
    """Scrape real estate listings for a given zip code"""
    url = f"https://example-realestate.com/search/{zip_code}/page-{page}"
    
    # Rotate user agents to avoid detection
    headers = {
        'User-Agent': random.choice(user_agents),
        'Accept': 'text/html,application/xhtml+xml,application/xml',
        'Accept-Language': 'en-US,en;q=0.9',
    }
    
    response = requests.get(url, headers=headers)
    
    if response.status_code != 200:
        print(f"Failed to retrieve data: {response.status_code}")
        return []
    
    soup = BeautifulSoup(response.text, 'html.parser')
    properties = []
    
    # Find all property listings on the page
    listings = soup.select('.property-listing')
    
    for listing in listings:
        try:
            # Extract property details
            address = listing.select_one('.property-address').text.strip()
            price = listing.select_one('.property-price').text.strip()
            price = int(price.replace('$', '').replace(',', ''))
            
            bedrooms = listing.select_one('.property-beds').text.strip()
            bathrooms = listing.select_one('.property-baths').text.strip()
            sqft = listing.select_one('.property-sqft').text.strip()
            sqft = int(sqft.replace(',', '').replace('sqft', '').strip())
            
            property_type = listing.select_one('.property-type').text.strip()
            listing_date = listing.select_one('.listing-date').text.strip()
            
            # Calculate price per square foot
            price_per_sqft = round(price / sqft, 2)
            
            properties.append({
                'address': address,
                'price': price,
                'bedrooms': bedrooms,
                'bathrooms': bathrooms,
                'sqft': sqft,
                'price_per_sqft': price_per_sqft,
                'property_type': property_type,
                'listing_date': listing_date,
                'zip_code': zip_code,
                'scrape_date': datetime.now().strftime('%Y-%m-%d')
            })
        except Exception as e:
            print(f"Error parsing listing: {e}")
    
    return properties

# Example usage
zip_codes = ['90210', '10001', '60601', '77002', '98101']
all_properties = []

for zip_code in zip_codes:
    print(f"Scraping data for {zip_code}...")
    
    # Scrape first 3 pages for each zip code
    for page in range(1, 4):
        properties = get_property_data(zip_code, page)
        all_properties.extend(properties)
        
        # Be nice to the server with a delay
        time.sleep(random.uniform(3, 7))
    
    print(f"Found {len(properties)} properties in {zip_code}")

# Convert to DataFrame and save
df = pd.DataFrame(all_properties)
df.to_csv('real_estate_data.csv', index=False)

print(f"Total properties collected: {len(df)}")
print(f\"Average price: ${df['price\'].mean():.2f}")
print(f"Average price per sqft: ${df['price_per_sqft'].mean():.2f}")
    },
  },
  {
    slug: "inventory-python-sql",
    title: "Inventory Management (Python & SQL)",
    description: "Automate inventory analysis with Pandas and PostgreSQL.",
    image: "https://images.unsplash.com/photo-1553413077-190dd305871c?auto=format&fit=crop&w=800&q=60",
    fullDescription:
      "Designed and implemented an inventory management system using Python and PostgreSQL. The system automates inventory tracking, analysis, and reporting to optimize stock levels and reduce costs.",
    technologies: ["Python", "Pandas", "PostgreSQL", "Data Analysis"],
    keyFeatures: [
      "Real-time inventory tracking",
      "Demand forecasting",
      "Automated reorder point calculation",
      "Inventory optimization reports",
    ],
    codeExample: {
      language: "python",
      code: `import pandas as pd
import numpy as np
import psycopg2
from sqlalchemy import create_engine
from datetime import datetime, timedelta
import matplotlib.pyplot as plt

# Database connection
def get_db_connection():
    conn = psycopg2.connect(
        host="localhost",
        database="inventory_db",
        user="inventory_user",
        password="password"
    )
    return conn

# Function to get current inventory levels
def get_inventory_levels():
    conn = get_db_connection()
    query = """
    SELECT 
        p.product_id,
        p.product_name,
        p.category,
        p.supplier_id,
        i.quantity_on_hand,
        i.reorder_point,
        i.reorder_quantity,
        i.last_restock_date,
        p.unit_price,
        p.unit_cost
    FROM 
        products p
    JOIN 
        inventory i ON p.product_id = i.product_id
    """
    inventory_df = pd.read_sql(query, conn)
    conn.close()
    return inventory_df

# Function to get sales history
def get_sales_history(days=90):
    conn = get_db_connection()
    query = f"""
    SELECT 
        s.product_id,
        p.product_name,
        s.sale_date,
        s.quantity_sold,
        s.sale_price
    FROM 
        sales s
    JOIN 
        products p ON s.product_id = p.product_id
    WHERE 
        s.sale_date >= CURRENT_DATE - INTERVAL '{days} days'
    ORDER BY 
        s.sale_date
    """
    sales_df = pd.read_sql(query, conn)
    conn.close()
    return sales_df

# Calculate reorder points based on lead time and sales velocity
def calculate_reorder_points(inventory_df, sales_df):
    # Group sales by product and calculate daily sales rate
    sales_summary = sales_df.groupby('product_id').agg({
        'quantity_sold': 'sum',
        'sale_date': ['min', 'max']
    })
    
    sales_summary.columns = ['total_sold', 'first_sale', 'last_sale']
    
    # Calculate days in the sales period
    sales_summary['days_in_period'] = (sales_summary['last_sale'] - sales_summary['first_sale']).dt.days + 1
    
    # Calculate daily sales rate
    sales_summary['daily_sales_rate'] = sales_summary['total_sold'] / sales_summary['days_in_period']
    
    # Merge with inventory data
    inventory_with_sales = pd.merge(
        inventory_df,
        sales_summary[['daily_sales_rate']],
        left_on='product_id',
        right_index=True,
        how='left'
    )
    
    # Fill missing values for products with no sales
    inventory_with_sales['daily_sales_rate'] = inventory_with_sales['daily_sales_rate'].fillna(0)
    
    # Assume 14 days lead time and 7 days safety stock
    lead_time = 14
    safety_stock_days = 7
    
    # Calculate reorder point
    inventory_with_sales['calculated_reorder_point'] = np.ceil(
        inventory_with_sales['daily_sales_rate'] * (lead_time + safety_stock_days)
    )
    
    return inventory_with_sales

# Identify items that need reordering
def identify_reorder_items(inventory_df):
    reorder_needed = inventory_df[inventory_df['quantity_on_hand'] <= inventory_df['reorder_point']]
    return reorder_needed.sort_values('quantity_on_hand')

# Main function
def run_inventory_analysis():
    # Get data
    inventory_df = get_inventory_levels()
    sales_df = get_sales_history(90)
    
    # Calculate reorder points
    inventory_analysis = calculate_reorder_points(inventory_df, sales_df)
    
    # Identify items needing reorder
    reorder_items = identify_reorder_items(inventory_analysis)
    
    # Print summary
    print(f"Total products: {len(inventory_df)}")
    print(f"Products needing reorder: {len(reorder_items)}")
    
    # Calculate inventory value
    total_inventory_value = (inventory_df['quantity_on_hand'] * inventory_df['unit_cost']).sum()
    print(f"Total inventory value: ${total_inventory_value:,.2f}")
    
    # Return analysis results
    return {
        'inventory': inventory_df,
        'sales': sales_df,
        'analysis': inventory_analysis,
        'reorder_items': reorder_items
    }

# Run the analysis
results = run_inventory_analysis()

# Display items that need reordering
print("\nItems that need reordering:")
print(results['reorder_items'][['product_name', 'quantity_on_hand', 'reorder_point', 'reorder_quantity']])`
    },
  },
  {
    slug: "data-pipeline",
    title: "ETL Pipeline for E-Commerce",
    description: "Extract, transform, and load data into Snowflake using Airflow.",
    image: "https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=800&q=60",
    fullDescription:
      "Built a robust ETL pipeline for an e-commerce platform using Apache Airflow and Snowflake. The pipeline extracts data from multiple sources, transforms it for analysis, and loads it into a data warehouse for business intelligence.",
    technologies: ["Apache Airflow", "Snowflake", "Python", "SQL", "ETL"],
    keyFeatures: [
      "Automated data extraction from multiple sources",
      "Data transformation and cleaning",
      "Scheduled data loading into Snowflake",
      "Error handling and monitoring",
    ],
    codeExample: {
      language: "python",
      code: `from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
import pandas as pd
import json
import requests

# Default arguments for the DAG
default_args = {
    'owner': 'data_team',
    'depends_on_past': False,
    'start_date': datetime(2023, 1, 1),
    'email': ['data_alerts@example.com'],
    'email_on_failure': True,
    'email_on_retry': False,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

# Create the DAG
dag = DAG(
    'ecommerce_etl_pipeline',
    default_args=default_args,
    description='ETL pipeline for e-commerce data',
    schedule_interval='0 2 * * *',  # Run daily at 2 AM
    catchup=False,
)

# Function to extract data from API
def extract_orders_data(**kwargs):
    """Extract order data from the e-commerce API"""
    # Get yesterday's date
    yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
    
    # API endpoint
    api_url = f"https://api.ecommerce-platform.com/v1/orders?date={yesterday}"
    
    # API authentication
    headers =
{
  ;("Authorization")
  : 'Bearer {{ var.value.ecommerce_api_key }}',
        'Content-Type': 'application/json'
}

#
Make
API
request
response = requests.get(api_url, (headers = headers))

if response.status_code != 200
:
        raise Exception(f"API request failed with status code {response.status_code}")
    
    # Parse response
    orders_data = response.json()
    
    # Save to S3
    s3_hook = S3Hook(aws_conn_id='aws_default')
    s3_hook.load_string(
        json.dumps(orders_data),
        f'orders/raw/{yesterday}.json',
        bucket_name='ecommerce-data-lake'
    )
    
    # Return the file path
for the next task
    return f
;
;("s3://ecommerce-data-lake/orders/raw/{yesterday}.json")

#
Function
to
transform
order
data
def
transform_orders_data(**kwargs)
:
    """Transform and clean the order data"""
    # Get the file path from the previous task
    ti = kwargs['ti']
    s3_file_path = ti.xcom_pull(task_ids='extract_orders_data')
    
    # Extract bucket name and key
    bucket_name = s3_file_path.split('//')[1].split('/')[0]
    key = '/'.join(s3_file_path.split('//')[1].split('/')[1:])
    
    # Get data from S3
    s3_hook = S3Hook(aws_conn_id='aws_default')
    orders_raw = json.loads(s3_hook.read_key(key, bucket_name))
    
    # Convert to DataFrame
    orders_df = pd.DataFrame(orders_raw['orders'])
    
    # Data cleaning and transformation
    # 1. Convert timestamps to datetime
    orders_df['order_date'] = pd.to_datetime(orders_df['order_date'])
    
    # 2. Extract customer information
    orders_df['customer_id'] = orders_df['customer'].apply(lambda x: x.get('id'))
    orders_df['customer_email'] = orders_df['customer'].apply(lambda x: x.get('email'))
    orders_df['customer_name'] = orders_df['customer'].apply(lambda x: f"{x.get('first_name')} {x.get('last_name')}")
    
    # 3. Calculate order metrics
    orders_df['item_count'] = orders_df['line_items'].apply(len)
    orders_df['order_total'] = orders_df['line_items'].apply(
        lambda items: sum(item.get('price', 0) * item.get('quantity', 0)
for item in items)
)
    
    # 4. Flatten line items into separate rows
    line_items = []
for order_id, order in orders_df[['id', 'line_items']].iterrows()
:
for item in order['line_items']
:
            line_items.append(
{
  ;("order_id")
  : order['id'],
                'product_id': item.get('product_id'),
                'product_name': item.get('product_name'),
                'quantity': item.get('quantity'),
                'price': item.get('price'),
                'total': item.get('price', 0) * item.get('quantity', 0)
}
)
    
    line_items_df = pd.DataFrame(line_items)
    
    # 5. Drop unnecessary columns
    orders_df = orders_df.drop(['customer', 'line_items'], axis=1)
    
    # Save transformed data to S3
    yesterday = (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d')
    
    # Save orders
    orders_csv = orders_df.to_csv(index=False)
    s3_hook.load_string(
        orders_csv,
        f'orders/transformed/orders_{yesterday}.csv',
        bucket_name='ecommerce-data-lake'
    )
    
    # Save line items
    line_items_csv = line_items_df.to_csv(index=False)
    s3_hook.load_string(
        line_items_csv,
        f'orders/transformed/line_items_{yesterday}.csv',
        bucket_name='ecommerce-data-lake'
    )

return {
        'orders_file': f's3://ecommerce-data-lake/orders/transformed/orders_{yesterday}.csv',
        'line_items_file': f's3://ecommerce-data-lake/orders/transformed/line_items_{yesterday}.csv'
    }

#
Create
Snowflake
tables
if they don
't exist
create_tables_sql = """
-- Create orders table
if it doesn
't exist
CREATE TABLE IF NOT EXISTS orders (
    id VARCHAR(50) PRIMARY KEY,
    order_date TIMESTAMP,
    customer_id VARCHAR(50),
    customer_email VARCHAR(100),
    customer_name VARCHAR(100),
    item_count INT,
    order_total DECIMAL(10,2),
    status VARCHAR(50),
    shipping_address VARCHAR(255),
    shipping_city VARCHAR(100),
    shipping_state VARCHAR(50),
    shipping_postal_code VARCHAR(20),
    shipping_country VARCHAR(50)
)

--Create
line
items
table
if it doesn
't exist
CREATE TABLE IF NOT EXISTS order_line_items (
    id INT IDENTITY(1,1) PRIMARY KEY,
    order_id VARCHAR(50),
    product_id VARCHAR(50),
    product_name VARCHAR(100),
    quantity INT,
    price DECIMAL(10,2),
    total DECIMAL(10,2),
    FOREIGN KEY (order_id) REFERENCES orders(id)
)
;("")
"

# SQL to load data from S3 to Snowflake
load_orders_sql = """
-- Load orders data
COPY INTO orders
FROM '{{ ti.xcom_pull(task_ids="transform_orders_data")["orders_file"] }}'
FILE_FORMAT = (TYPE = 'CSV' FIELD_OPTIONALLY_ENCLOSED_BY = '"' SKIP_HEADER = 1)
ON_ERROR = 'CONTINUE'
;("")
"

load_line_items_sql = """
-- Load line items data
COPY INTO order_line_items (order_id, product_id, product_name, quantity, price, total)
FROM '{{ ti.xcom_pull(task_ids="transform_orders_data")["line_items_file"] }}'
FILE_FORMAT = (TYPE = 'CSV' FIELD_OPTIONALLY_ENCLOSED_BY = '"' SKIP_HEADER = 1)
ON_ERROR = 'CONTINUE'
;("")
"

# Define the tasks
extract_task = PythonOperator(
    task_id='extract_orders_data',
    python_callable=extract_orders_data,
    provide_context=True,
    dag=dag,
)

transform_task = PythonOperator(
    task_id='transform_orders_data',
    python_callable=transform_orders_data,
    provide_context=True,
    dag=dag,
)

create_tables_task = SnowflakeOperator(
    task_id='create_snowflake_tables',
    sql=create_tables_sql,
    snowflake_conn_id='snowflake_conn',
    dag=dag,
)

load_orders_task = SnowflakeOperator(
    task_id='load_orders_to_snowflake',
    sql=load_orders_sql,
    snowflake_conn_id='snowflake_conn',
    dag=dag,
)

load_line_items_task = SnowflakeOperator(
    task_id='load_line_items_to_snowflake',
    sql=load_line_items_sql,
    snowflake_conn_id='snowflake_conn',
    dag=dag,
)

# Define task dependencies
extract_task >> transform_task >> create_tables_task >> [load_orders_task, load_line_items_task]

export default function ProjectPage() {
  const params = useParams()
  const { slug } = params

  // Find the project based on the slug
  const project = projectsData.find((p) => p.slug === slug)

  if (!project) {
    return <div>Project not found</div>
  }

  return (
    <div className="container mx-auto mt-8">
      <Link href="/projects">
        <div className="flex items-center mb-4 text-blue-500 hover:text-blue-700">
          <FaArrowLeft className="mr-2" /> Back to Projects
        </div>
      </Link>
      <div className="mb-4">
        <h1 className="text-3xl font-bold">{project.title}</h1>
        <p className="text-gray-600">{project.description}</p>
      </div>
      <Image
        src={project.image || "/placeholder.svg"}
        alt={project.title}
        width={800}
        height={400}
        className="rounded-md mb-4"
      />
      <div className="mb-4">
        <h2 className="text-2xl font-semibold">Full Description</h2>
        <p className="text-gray-700">{project.fullDescription}</p>
      </div>
      <div className="mb-4">
        <h2 className="text-2xl font-semibold">Technologies Used</h2>
        <ul className="list-disc list-inside text-gray-700">
          {project.technologies.map((tech, index) => (
            <li key={index}>{tech}</li>
          ))}
        </ul>
      </div>
      <div className="mb-4">
        <h2 className="text-2xl font-semibold">Key Features</h2>
        <ul className="list-disc list-inside text-gray-700">
          {project.keyFeatures.map((feature, index) => (
            <li key={index}>{feature}</li>
          ))}
        </ul>
      </div>
      {project.codeExample && (
        <div className="mb-4">
          <h2 className="text-2xl font-semibold">Code Example</h2>
          <p className="text-gray-700">{project.codeExample.title}</p>
          <SyntaxHighlighter language={project.codeExample.language} style={dracula}>
            {project.codeExample.code}
          </SyntaxHighlighter>
        </div>
      )}
      <div className="flex space-x-4">
        <Link href="https://github.com" target="_blank" rel="noopener noreferrer">
          <FaGithub className="text-gray-500 hover:text-gray-700" size={24} />
        </Link>
        <Link href="https://linkedin.com" target="_blank" rel="noopener noreferrer">
          <FaLinkedinIn className="text-gray-500 hover:text-gray-700" size={24} />
        </Link>
      </div>
    </div>
  )
}
